const http = require('http');

const html = `<!doctype html>
<html lang="ru"><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>MyShop Web MVP</title>
<style>body{font-family:Arial,sans-serif;padding:24px}a{display:block;margin:8px 0}</style>
</head><body>
<h1>MyShop Web MVP</h1>
<p>Стартовый каркас веб-версии запущен.</p>
<a href="/health">/health</a>
<a href="/roadmap">/roadmap</a>
</body></html>`;

const server = http.createServer((req, res) => {
  if (req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({ ok: true, service: 'web' }));
  }
  if (req.url === '/roadmap') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({
      modules: ['catalog', 'product-card', 'cart', 'checkout', 'profile-orders', 'admin'],
      status: 'in-progress'
    }));
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(html);
});

server.listen(3000, () => {
  console.log('Web running on http://localhost:3000');
});
