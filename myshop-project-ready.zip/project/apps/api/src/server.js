const http = require('http');

const products = [
  { id: 1, name: 'Кроссовки Urban', price: 4990, sizes: ['40', '41', '42'] },
  { id: 2, name: 'Куртка Street', price: 7990, sizes: ['M', 'L', 'XL'] }
];

const server = http.createServer((req, res) => {
  if (req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({ ok: true, service: 'api' }));
  }

  if (req.url === '/api/products') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({ items: products }));
  }

  res.writeHead(404, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify({ error: 'Not found' }));
});

server.listen(4000, () => {
  console.log('API running on http://localhost:4000');
});
