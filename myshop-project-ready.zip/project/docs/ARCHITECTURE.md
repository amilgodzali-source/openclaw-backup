# ARCHITECTURE

## Цель
Альтернатива Wildberries с собственными изменениями:
- web витрина
- mobile приложение
- личный кабинет заказов
- backend API

## Репозиторий (monorepo)
- `apps/web` — web клиент
- `apps/mobile` — mobile клиент
- `apps/api` — backend
- `packages/shared` — общие контракты
- `mockups` — исходные макеты заказчика

## MVP модули
1. Каталог
2. Карточка товара
3. Корзина
4. Checkout
5. Личный кабинет (мои заказы)
6. Админка (товары/заказы)
