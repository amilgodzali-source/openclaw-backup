# Marketplace Project

Проект маркетплейса (альтернатива WB) с веб-версией, мобильным приложением и личным кабинетом.

## Структура

- `mockups/` — исходные HTML-макеты (получены от заказчика)
- `apps/web` — web-клиент (каталог, корзина, checkout, заказы)
- `apps/api` — backend API (товары, заказы)
- `apps/mobile` — мобильное приложение (пока каркас)
- `packages/shared` — общие контракты (каркас)
- `docs/` — архитектура, roadmap, handover

## Что уже работает

- Каталог в web тянет товары из API
- Корзина: добавить/увеличить/уменьшить/удалить
- Checkout: валидация + создание заказа
- Личный кабинет: список заказов
- API: `GET /api/products`, `GET /api/orders`, `POST /api/orders`
- API поддерживает 2 режима хранения заказов:
  - `postgres` (если есть `DATABASE_URL` и установлен `pg`)
  - `memory` fallback (если БД не настроена)

## Запуск

```bash
cd project
npm install
npm run dev:api
npm run dev:web
```

Открыть: `http://localhost:3000`

## PostgreSQL

1. Подними Postgres
2. Укажи `DATABASE_URL` в окружении
3. Запусти API — таблица `orders` создастся автоматически

Пример:

```bash
export DATABASE_URL='postgres://user:password@localhost:5432/myshop'
npm run dev:api
```
