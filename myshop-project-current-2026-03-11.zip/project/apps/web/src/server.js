const http = require('http');

const API_BASE = process.env.API_BASE || 'http://localhost:4000';
const cart = [{ productId: 1, qty: 1 }];

function layout(title, content) {
  return `<!doctype html>
<html lang="ru">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>${title}</title>
  <style>
    *{box-sizing:border-box} body{margin:0;font-family:Inter,Arial,sans-serif;background:#f4f5f7;color:#1f2937}
    .top{position:sticky;top:0;background:#ffd54a;padding:12px 16px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 8px rgba(0,0,0,.1)}
    .logo{font-weight:800;font-size:20px}.wrap{max-width:1100px;margin:0 auto;padding:20px 16px}
    .tabs{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 16px}.tab{padding:8px 12px;border-radius:10px;background:#fff;border:1px solid #e5e7eb;text-decoration:none;color:#111827;font-size:14px}
    .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px}.card{background:#fff;border-radius:14px;border:1px solid #e5e7eb;padding:14px;display:flex;flex-direction:column;gap:10px}
    .img{height:140px;border-radius:10px;background:linear-gradient(135deg,#eef2ff,#fef3c7)}
    .name{font-weight:700;font-size:15px}.price{font-weight:800;font-size:18px}.muted{color:#6b7280}
    .hero{background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:18px;margin-bottom:16px}
    .btn{background:#111827;color:#fff;border:none;border-radius:10px;padding:10px 12px;font-weight:600;cursor:pointer}
    .line{display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid #f3f4f6;align-items:center}
    .input{width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:10px;margin:6px 0 10px}
    .box{background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:14px;max-width:760px}
    .actions{display:flex;gap:6px;align-items:center}
    .tiny{font-size:12px;padding:5px 8px;border-radius:8px;border:1px solid #d1d5db;background:#fff;text-decoration:none;color:#111827}
    .error{background:#fef2f2;border:1px solid #fecaca;color:#991b1b;padding:10px;border-radius:10px;margin-bottom:10px}
  </style>
</head><body><header class="top"><div class="logo">МойШоп</div><div style="font-size:13px">MVP v0.4</div></header><main class="wrap">${content}</main></body></html>`;
}

function reqJson(method, path, payload) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, API_BASE);
    const body = payload ? JSON.stringify(payload) : null;
    const req = http.request({ method, hostname: url.hostname, port: url.port, path: url.pathname + url.search, headers: { 'Content-Type': 'application/json', 'Content-Length': body ? Buffer.byteLength(body) : 0 } }, (res) => {
      let data = '';
      res.on('data', (d) => (data += d));
      res.on('end', () => {
        try { resolve(JSON.parse(data || '{}')); } catch { resolve({}); }
      });
    });
    req.on('error', reject);
    req.setTimeout(2000, () => req.destroy(new Error('timeout')));
    if (body) req.write(body);
    req.end();
  });
}

function pageNav() {
  return `<nav class="tabs"><a class="tab" href="/">Каталог</a><a class="tab" href="/cart">Корзина</a><a class="tab" href="/checkout">Оформление</a><a class="tab" href="/profile/orders">Мои заказы</a><a class="tab" href="/health">Health</a></nav>`;
}

async function products() {
  const data = await reqJson('GET', '/api/products');
  return Array.isArray(data.items) ? data.items : [];
}

async function catalogView() {
  const list = await products();
  const cards = list.map((p) => `<article class="card"><div class="img"></div><div class="name">${p.name}</div><div class="price">${Number(p.price).toLocaleString('ru-RU')} ₽</div><div class="muted">Размеры: ${(p.sizes || []).join(', ')}</div><a class="tab" href="/cart/add?productId=${p.id}">В корзину</a></article>`).join('');
  return layout('Каталог', `<section class="hero"><h1 style="margin:0 0 8px">Каталог</h1><div class="muted">Товары грузятся из API. Корзина/checkout уже рабочие.</div></section>${pageNav()}<section class="grid">${cards}</section>`);
}

async function cartView() {
  const list = await products();
  const rows = cart.map((c) => {
    const p = list.find((x) => x.id === c.productId);
    if (!p) return '';
    return `<div class="line"><div><div>${p.name}</div><div class="muted">${p.price.toLocaleString('ru-RU')} ₽ за шт.</div></div><div class="actions"><a class="tiny" href="/cart/dec?productId=${p.id}">-</a><strong>${c.qty}</strong><a class="tiny" href="/cart/inc?productId=${p.id}">+</a><a class="tiny" href="/cart/remove?productId=${p.id}">Удалить</a></div><div><strong>${(p.price * c.qty).toLocaleString('ru-RU')} ₽</strong></div></div>`;
  }).join('');
  const total = cart.reduce((acc, c) => {
    const p = list.find((x) => x.id === c.productId);
    return acc + (p ? p.price * c.qty : 0);
  }, 0);
  return layout('Корзина', `${pageNav()}<section class="box"><h2 style="margin:0 0 10px">Корзина</h2>${rows || '<div class="muted">Корзина пустая</div>'}<div class="line" style="border-bottom:none;font-weight:800"><div>Итого</div><div>${total.toLocaleString('ru-RU')} ₽</div></div></section>`);
}

function checkoutView(error = '') {
  return layout('Оформление', `${pageNav()}<section class="box"><h2 style="margin:0 0 10px">Оформление заказа</h2>${error ? `<div class="error">${error}</div>` : ''}<form method="POST" action="/checkout"><input class="input" name="customerName" placeholder="Имя" required /><input class="input" name="phone" placeholder="Телефон" required /><input class="input" name="city" placeholder="Город" required /><button class="btn" type="submit">Подтвердить заказ</button></form></section>`);
}

async function ordersView() {
  const data = await reqJson('GET', '/api/orders');
  const items = Array.isArray(data.items) ? data.items : [];
  const list = items.map((o) => `<div class="card"><div class="name">Заказ #${o.id} — ${o.status}</div><div class="muted">${o.customerName}, ${o.city}, ${o.phone}</div><div class="price">${Number(o.total).toLocaleString('ru-RU')} ₽</div></div>`).join('');
  return layout('Мои заказы', `${pageNav()}<section class="grid">${list || '<div class="muted">Заказов пока нет</div>'}</section>`);
}

function parseForm(req) {
  return new Promise((resolve) => {
    let data = '';
    req.on('data', (d) => (data += d));
    req.on('end', () => {
      const params = new URLSearchParams(data);
      resolve({ customerName: (params.get('customerName') || '').trim(), phone: (params.get('phone') || '').trim(), city: (params.get('city') || '').trim() });
    });
  });
}

function findItem(id) {
  return cart.find((x) => x.productId === id);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');

  if (url.pathname === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({ ok: true, service: 'web', cartItems: cart.length }));
  }

  if (url.pathname.startsWith('/cart/')) {
    const id = Number(url.searchParams.get('productId'));
    const item = findItem(id);
    if (url.pathname === '/cart/add' || url.pathname === '/cart/inc') {
      if (id) {
        if (item) item.qty += 1;
        else cart.push({ productId: id, qty: 1 });
      }
    }
    if (url.pathname === '/cart/dec' && item) {
      item.qty -= 1;
      if (item.qty <= 0) {
        const idx = cart.findIndex((x) => x.productId === id);
        if (idx >= 0) cart.splice(idx, 1);
      }
    }
    if (url.pathname === '/cart/remove' && id) {
      const idx = cart.findIndex((x) => x.productId === id);
      if (idx >= 0) cart.splice(idx, 1);
    }
    res.writeHead(302, { Location: '/cart' });
    return res.end();
  }

  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/catalog')) {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end(await catalogView());
  }
  if (req.method === 'GET' && url.pathname === '/cart') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end(await cartView());
  }
  if (req.method === 'GET' && url.pathname === '/checkout') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end(checkoutView());
  }
  if (req.method === 'POST' && url.pathname === '/checkout') {
    const form = await parseForm(req);
    if (!cart.length) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(checkoutView('Корзина пустая. Добавь товары из каталога.'));
    }
    if (!form.customerName || !form.phone || !form.city) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(checkoutView('Заполни все поля: имя, телефон и город.'));
    }
    const result = await reqJson('POST', '/api/orders', { ...form, items: cart });
    if (!result.ok) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(checkoutView(`Ошибка API: ${result.error || 'неизвестно'}`));
    }
    cart.length = 0;
    res.writeHead(302, { Location: '/profile/orders' });
    return res.end();
  }
  if (req.method === 'GET' && url.pathname === '/profile/orders') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end(await ordersView());
  }

  res.writeHead(404, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify({ error: 'Not found' }));
});

server.listen(3000, () => {
  console.log('Web running on http://localhost:3000');
});
