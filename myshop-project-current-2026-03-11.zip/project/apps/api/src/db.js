let Pool = null;
try {
  ({ Pool } = require('pg'));
} catch {}

const hasPg = !!Pool;
const canUsePg = !!process.env.DATABASE_URL && hasPg;

const memory = {
  orders: [],
  seq: 1001
};

let pool = null;

async function initDb() {
  if (!canUsePg) return { mode: hasPg ? 'memory_no_url' : 'memory_no_pg' };
  pool = new Pool({ connectionString: process.env.DATABASE_URL });
  await pool.query(`
    CREATE TABLE IF NOT EXISTS orders (
      id BIGSERIAL PRIMARY KEY,
      status TEXT NOT NULL,
      customer_name TEXT NOT NULL,
      phone TEXT NOT NULL,
      city TEXT NOT NULL,
      items_json JSONB NOT NULL,
      total INTEGER NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `);
  return { mode: 'postgres' };
}

async function listOrders() {
  if (!pool) return memory.orders.slice().reverse();
  const { rows } = await pool.query(
    `SELECT id, status, customer_name, phone, city, items_json, total, created_at
     FROM orders
     ORDER BY id DESC`
  );
  return rows.map((r) => ({
    id: Number(r.id),
    status: r.status,
    customerName: r.customer_name,
    phone: r.phone,
    city: r.city,
    items: r.items_json,
    total: r.total,
    createdAt: r.created_at
  }));
}

async function createOrder(orderInput) {
  if (!pool) {
    const order = {
      id: memory.seq++,
      ...orderInput,
      createdAt: new Date().toISOString()
    };
    memory.orders.push(order);
    return order;
  }

  const { rows } = await pool.query(
    `INSERT INTO orders (status, customer_name, phone, city, items_json, total)
     VALUES ($1,$2,$3,$4,$5,$6)
     RETURNING id, status, customer_name, phone, city, items_json, total, created_at`,
    [
      orderInput.status,
      orderInput.customerName,
      orderInput.phone,
      orderInput.city,
      JSON.stringify(orderInput.items),
      orderInput.total
    ]
  );

  const r = rows[0];
  return {
    id: Number(r.id),
    status: r.status,
    customerName: r.customer_name,
    phone: r.phone,
    city: r.city,
    items: r.items_json,
    total: r.total,
    createdAt: r.created_at
  };
}

module.exports = {
  initDb,
  listOrders,
  createOrder,
  dbMeta: { hasPg }
};
