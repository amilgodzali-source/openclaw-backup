const http = require('http');
const { initDb, listOrders, createOrder, dbMeta } = require('./db');

const products = [
  { id: 1, name: 'Кроссовки Urban', price: 4990, sizes: ['40', '41', '42'] },
  { id: 2, name: 'Куртка Street', price: 7990, sizes: ['M', 'L', 'XL'] }
];

let dbMode = 'unknown';

function json(res, status, payload) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(payload));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 1_000_000) {
        reject(new Error('Payload too large'));
        req.destroy();
      }
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try {
        resolve(JSON.parse(data));
      } catch {
        reject(new Error('Invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'GET' && req.url === '/health') {
    let ordersCount = 0;
    try {
      ordersCount = (await listOrders()).length;
    } catch {}
    return json(res, 200, { ok: true, service: 'api', orders: ordersCount, dbMode, pgInstalled: dbMeta.hasPg });
  }

  if (req.method === 'GET' && req.url === '/api/products') {
    return json(res, 200, { items: products });
  }

  if (req.method === 'GET' && req.url === '/api/orders') {
    try {
      return json(res, 200, { items: await listOrders() });
    } catch (e) {
      return json(res, 500, { error: `DB read error: ${e.message}` });
    }
  }

  if (req.method === 'POST' && req.url === '/api/orders') {
    try {
      const body = await readBody(req);
      const customerName = String(body.customerName || '').trim();
      const phone = String(body.phone || '').trim();
      const city = String(body.city || '').trim();
      const items = Array.isArray(body.items) ? body.items : [];

      if (!customerName || !phone || !city || !items.length) {
        return json(res, 400, { error: 'customerName, phone, city и items обязательны' });
      }

      const enriched = items
        .map((it) => {
          const p = products.find((x) => x.id === Number(it.productId));
          if (!p) return null;
          const qty = Math.max(1, Number(it.qty) || 1);
          return { productId: p.id, name: p.name, price: p.price, qty, sum: p.price * qty };
        })
        .filter(Boolean);

      if (!enriched.length) {
        return json(res, 400, { error: 'Нет валидных товаров в заказе' });
      }

      const total = enriched.reduce((acc, it) => acc + it.sum, 0);
      const order = await createOrder({
        status: 'new',
        customerName,
        phone,
        city,
        items: enriched,
        total
      });

      return json(res, 201, { ok: true, order });
    } catch (e) {
      return json(res, 400, { error: e.message || 'Bad request' });
    }
  }

  json(res, 404, { error: 'Not found' });
});

initDb()
  .then((meta) => {
    dbMode = meta.mode;
    server.listen(4000, () => {
      console.log(`API running on http://localhost:4000 (dbMode=${dbMode})`);
    });
  })
  .catch((err) => {
    console.error('DB init failed:', err.message);
    process.exit(1);
  });
