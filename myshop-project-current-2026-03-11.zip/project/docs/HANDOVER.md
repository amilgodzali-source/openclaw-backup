# HANDOVER (для разработчика)

## Что уже сделано
- Приняты 3 исходных макета (shop/mobile/cabinet)
- Развернута структура monorepo
- Добавлены стартовые web/api сервисы
- Реализован рабочий MVP-flow в web:
  - каталог
  - корзина (add/inc/dec/remove)
  - checkout (валидация + создание заказа)
  - страница заказов
- Реализованы API endpoints:
  - `GET /api/products`
  - `GET /api/orders`
  - `POST /api/orders`
- Подключен слой БД в API:
  - Postgres режим при `DATABASE_URL`
  - fallback in-memory (если БД не настроена)

## Как запустить локально
```bash
cd project
npm install
npm run dev:api
npm run dev:web
```

## Проверка API
```bash
curl http://localhost:4000/health
curl http://localhost:4000/api/products
curl http://localhost:4000/api/orders
```

## Следующие задачи
- Перенос UI из `mockups/*.html` в полноценную компонентную структуру (React/Next)
- Подключение реальной авторизации
- PostgreSQL миграции + отдельные таблицы users/order_items/products
- Реализация админки (CRUD товаров, статусы заказов)
- Подготовка mobile app на общем API
